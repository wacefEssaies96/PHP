<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php
        include 'tableaux.php';

        echo '<h2>Solution 1</h2>';
        echo '<table border="1">';
        echo '<tr>';
        for ($i=1; $i <=12 ; $i++) { 
            echo '<td>'.$i.'</td>';
            echo '<td bgcolor="'.$couleur[$i].'">'.$mois[$i].'</td>';
            ($i % 3 == 0) ? print '</tr><tr>' : print '';
        }
        echo '</tr>';
        echo '</table>';

        //solution 2
        echo '<hr>';
        echo '<h2>Solution 2</h2>';
        echo '<table border="1">';
        echo '<tr>';
        foreach ($mois as $index => $value)
        {
            echo '<td>'.$index.'</td>';
            echo '<td bgcolor="'.$couleur[$index].'">'.$value.'</td>';
            ($index % 3 == 0) ? print '</tr><tr>' : print '';
        }
        echo '</tr>';
        echo '</table>';
    ?>
</body>
</html>