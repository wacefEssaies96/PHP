<?php

    $mois = array(1=>'Janvier','Février','Mars','Avril', 'Mai','Juin', 'Juillet','Aout','Septembre','Octobre', 'Novembre','Décembre');

    $couleur = array(1=>'blue','white','red','yellow', 'grey','lime', 'lightblue','fuchsia', 'lightgrey', 'olive','pink','purple');