<?php
    try {
        $cnx = new PDO('mysql:host=localhost;dbname=dsi22_g2_exemple1', 'root', '');
    } catch (Exception $e) {
        echo 'Erreur: '.$e;
    }