<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Date de naissance</th>
            <th>Etablissement d'origine</th>
            <th>Spécialité</th>
            <th>Durée du stage</th>
        </tr>
        <?php
            include 'dbconnect.php';
            
            $rep = $cnx->query('SELECT * FROM stagiaire');

            while($data = $rep->fetch())
            {
                echo '<tr>';
                echo '<td>'.$data['id'].'</td>';
                echo '<td>'.$data['nom'].'</td>';
                echo '<td>'.$data['dateNaissance'].'</td>';
                echo '<td>'.$data['etabOrigin'].'</td>';
                echo '<td>'.$data['spec'].'</td>';
                echo '<td>'.$data['duree'].'</td>';
                echo '</tr>';
            }
        ?>
    </table>
    
</body>
</html>