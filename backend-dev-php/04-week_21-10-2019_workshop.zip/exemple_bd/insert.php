<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="" method="post" accept-charset="utf-8">
		<label>Nom<input type="text" name="nom" ></label><br>
		<label>Date de naissance<input type="date" name="dateN"></label><br>
		<label>Etablissement d'origine<input type="text" name="etabOrigin"></label><br>
		<label>Spécialité<input type="text" name="spec"></label><br>
		<label>Durée<input type="number" max="6" name="duree" value=""></label><br>
		<input type="submit">
    </form>

    <?php
        if (!empty($_POST)) {
            $nom = $_POST['nom'];
            $dateN = $_POST['dateN'];
            $etabOrigin = $_POST['etabOrigin'];
            $spec = $_POST['spec'];
            $duree = $_POST['duree'];

            include 'dbconnect.php';

            $nb = $cnx->exec("INSERT INTO stagiaire(nom,dateNaissance,etabOrigin,spec,duree) VALUES ('$nom','$dateN','$etabOrigin','$spec','$duree')");

            echo $nb.' stagiaire ajouté avec succés';
        }
    ?>
</body>
</html>