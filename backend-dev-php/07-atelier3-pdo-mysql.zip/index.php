<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../bootstrap-4.3.1/css/bootstrap.min.css">
    <title>Etudinats DSI2</title>
</head>
<body>
    <div class="container py-3">
        <div class="jumbotron">
            <h3>Liste des étudiants DSI 2 ISET Bizerte 2018</h3>
        </div>
        <a href="create.html" class="btn btn-primary">Nouvel étudiant</a>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Operations</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    include 'dbconnect.php';
                    $rep = $pdo->prepare('SELECT * FROM students');
                    $rep->execute();
                    while($data = $rep->fetch())
                    {
                        echo '<tr>';
                        echo '<td>'.$data['id'].'</td>';
                        echo '<td>'.$data['firstname'].'</td>';
                        echo '<td>'.$data['lastname'].'</td>';
                        echo '<td>'.$data['email'].'</td>';
                        echo '<td>'.$data['phone'].'</td>';
                        echo '<td><a href="editer.php?id='.$data['id'].'">Editer</a>&nbsp;&nbsp;';
                        echo '<a href="delete.php?id='.$data['id'].'">Supprimer</a></td>';
                        echo '</tr>';
                    }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>