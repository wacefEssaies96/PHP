<?php

    include 'dbconnect.php';

    $req = $pdo->prepare('DELETE FROM students WHERE id= :param_id');
    $req->bindParam(':param_id', $_GET['id']);
    $req->execute();

    header('Location:index.php');