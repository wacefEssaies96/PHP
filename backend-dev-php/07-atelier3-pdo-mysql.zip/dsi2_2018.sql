-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 19, 2019 at 11:16 PM
-- Server version: 5.7.26
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dsi2_2018`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE IF NOT EXISTS `students` (
  `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(35) NOT NULL,
  `phone` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `firstname`, `lastname`, `email`, `phone`) VALUES
(2, 'Khadija', 'Rifi Gharbi', 'khadijarifigharbi@gmail.com', 99887744),
(3, 'Amani', 'Gharbi', 'amanigharbi9@gmail.com', 27727476),
(4, 'Wided', 'May', 'widedmay99@gmail.com', 24946164),
(5, 'Oumayma', 'Touati', 'oumaymatouati123@gmail.com', 24585459),
(6, 'Ibtihel', 'Awled Soula', 'ibtihelawledsoula@gmail.com', 27733695),
(7, 'Roukaya', 'Bel Hadj', 'roukayabel01@gmail.com', 55225509),
(8, 'Malek', 'Fetoui', 'malekfetoui98@gmail.com', 53083983),
(9, 'Samar', 'Ben Brahim', 'samar.benbrahim123@gmail.com', 95184910),
(10, 'Khaled', 'Abbes', 'khaledabbes69@gmail.com', 99887744),
(11, 'Houcem', 'Hedhly', 'irving.boehm@example.org', 52313532),
(12, 'Houcem', 'Hedhly', 'kristin.friesen@example.org', 99887744);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
