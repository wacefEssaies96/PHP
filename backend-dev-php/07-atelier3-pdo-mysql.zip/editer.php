<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../bootstrap-4.3.1/css/bootstrap.min.css">
    <title>Mise à jour étudiant</title>
</head>
<body>
    <?php
        require 'dbconnect.php';
        $req = $pdo->prepare('SELECT * FROM students WHERE id= :param_id');
        $req->bindParam(':param_id', $_GET['id']);
        $req->execute();
        $data = $req->fetch();
    ?>
    <div class="container py-3">
        <fieldset>
            <legend>Modifier un étudiant</legend>
            <form action="update.php" method="post">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="firstname">Firstname</label>
                            <input type="text" name="firstname" value="<?= $data['firstname'] ?>" id="firstname" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="lastname">Lastname</label>
                            <input type="text" name="lastname" value="<?= $data['lastname'] ?>" id="lastname" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="email">E-mail</label>
                            <input type="text" name="email" value="<?= $data['email'] ?>" id="email" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="phone">Phone</label>
                            <input type="text" name="phone" value="<?= $data['phone'] ?>" id="phone" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <input type="number" name="id" id="id" hidden value="<?= $data['id'] ?>">
                        <button class="btn btn-outline-primary" type="submit">Enregistrer</button>
                        <button class="btn btn-outline-secondary" type="reset">Annuler</button>
                    </div>
                </div>
            </form>
        </fieldset>
    </div>
</body>
</html>