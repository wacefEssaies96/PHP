<?php

    try {
        $pdo = new PDO('mysql:host=localhost;dbname=dsi2_2018', 'root', '');
    } catch (Exception $e) {
        die('Erreur: '.$e->getMessage());
    }