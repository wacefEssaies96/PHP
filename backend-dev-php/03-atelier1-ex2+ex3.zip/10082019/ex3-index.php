<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Exercice 3</title>
</head>
<body>
    <div class="container">
        <div class="jumbotron">
            <h1 class="text-center">DSI22 Store</h1>
        </div>
        <fieldset>
            <legend>Achats matériels informatiques</legend>
            <form action="ex3-trait.php" method="get">
                <div class="form-group">
                    <label for="vendeur">Liste des vendeurs</label>
                    <select name="vendeur" id="vendeur" class="form-control" multiple>
                    <?php
                            include 'listes.php'; //require 'listes.php;
                            foreach ($vendeurs as $elem)
                                echo '<option value="'.$elem.'">'.$elem.'</option>';
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="produit">Liste des produits</label>
                    <select name="produit" id="produit" class="form-control">
                        <option value="" selected disabled>Choisir un produit</option>
                        <?php
                            foreach ($produits as $elem)
                                echo '<option value="'.$elem.'">'.$elem.'</option>';
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="qt">Quantité à commander</label>
                    <input type="number" name="qt" id="qt" class="form-control">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-block btn-outline-success">Commander</button>
                </div>
            </form>
        </fieldset>
    </div>
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>