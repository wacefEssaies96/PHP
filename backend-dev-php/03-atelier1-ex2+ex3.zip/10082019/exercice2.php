<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Exercice 2</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <fieldset>
        <?php

            if (!empty($_POST)){
                //récupération des caleurs saisies par l'utilisateur
                $prixht = $_POST['prixht'];
                $txtva = $_POST['txtva'];

                //calcul du montant TVA et du prix TTC
                $mttva = $prixht * $txtva / 100;
                $pxttc = $prixht + $mttva;
                ?>

                <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    Montant TVA = <strong><?= $mttva;?></strong><br>
                    Montant TTC = <strong><?= $pxttc;?></strong>
                </div>

                <?php
            }
        ?>
            <legend>Calcul TVA</legend>
            <form action="" method="post">
                <div class="form-group">
                    <label for="prixht">Prix HT</label>
                    <input type="number" name="prixht" id="prixht" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="txtva">Taux TVA (en %)</label>
                    <input type="number" name="txtva" id="txtva" class="form-control" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-block btn-outline-warning">Calculer</button>
                </div>
            </form>
        </fieldset>
        <?php
            if(!empty($_POST)){
        ?>
        <!-- <hr>
        <h2 class="text-center">Résultat du calcul de la TVA</h2> -->
        <?php         
                //récupérer les valeurs saisies par l'utilisateur
                $prixht = $_POST['prixht'];
                $txtva = $_POST['txtva'];

                //calcul du prix TTC
                $mttva = $prixht * $txtva / 100;
                $prixttc = $prixht + $mttva;

                //affichage du résultat
                // echo '<label>Montant TVA</label>';
                // echo '<input type="text" class="form-control" value="'.$mttva.'" disabled>';
                // echo '<label>Prix TTC</label>';
                // echo '<input type="text" class="form-control" value="'.$prixttc.'" disabled>';
            }
            
        
        ?>
    </div>
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>