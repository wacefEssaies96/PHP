<?php
    $produits = array('Flash disk', 'Ordinateur portable', 'Ordinateur', 'Photocopieuse', 'Imprimante', 'Tablette', 'Smartphone');
    $vendeurs = ['MyTek', 'Tunisianet', 'Jumia', 'Wiki', 'Tdiscount'];