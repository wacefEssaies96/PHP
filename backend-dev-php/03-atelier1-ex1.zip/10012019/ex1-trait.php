<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Affichage des informations personnelles</title>
</head>
<body>
    <div class="container">
    <h3>Affichage des informations personnelles</h3>
    <table class="table table-hover">
        <thead>
            <tr>
                <th>Prénom</th>
                <th>Nom</th>
                <th>Email</th>
                <th>Adresse</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <?php
                    foreach ($_POST as $value) {
                        echo '<td>'.$value.'</td>';
                    }
                ?>
            </tr>
            <tr>
                <td><?php echo $_POST['prenom'] ?></td>
                <td><?php echo $_POST['nom'] ?></td>
                <td><?php echo $_POST['email'] ?></td>
                <td><?php echo $_POST['adresse'] ?></td>
            </tr>
        </tbody>
    </table>
    </div>
    <!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>